function ikRechnung(){
    let plz = document.getElementById("PLZ")
    let warenwert = document.getElementById("Warenwert")
    let prozent
    let zwischenschritt
    let ergebnis
    let express
        for(let i=0;i<=9;i++) {

            if (plz === 1 || plz === 2) {
                prozent = 5;
            } else if (plz === 3 || plz === 4 || plz === 5) {
                prozent = 7
            } else if (plz === 6 || plz === 7) {
                prozent = 9
            } else {
                prozent = 11
            }
        }
    if(document.getElementById("express")===true){
        zwischenschritt = warenwert/prozent
        ergebnis = warenwert*zwischenschritt
        express = ergebnis*20
        ergebnis = ergebnis+express
    }else {
        zwischenschritt = warenwert / prozent
        ergebnis = warenwert * zwischenschritt
    }
    console.log(express)
    console.log(zwischenschritt)
    console.log(prozent)
    console.log(ergebnis)
return ergebnis

}